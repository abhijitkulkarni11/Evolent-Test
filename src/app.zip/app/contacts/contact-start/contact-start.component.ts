import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-start',
  templateUrl: './contact-start.component.html',
  styleUrls: ['./contact-start.component.css']
})
export class ContactStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
