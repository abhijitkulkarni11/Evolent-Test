export class ContactNumber {
  constructor(public name: string, public amount: number) {}
}
